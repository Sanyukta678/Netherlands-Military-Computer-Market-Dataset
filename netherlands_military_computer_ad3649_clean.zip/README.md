# Netherlands Military Computer Market (AD3649)

This ZIP contains metadata and reference information for the Netherlands Military Computer Market report by NextMSC.

Contents:
- metadata.txt
- source_url.txt
- note.txt

The original PDF/sample must be downloaded directly from the publisher.
